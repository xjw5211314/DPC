				clear all;  
                clc;
                close all;
            
                load ('Dataset/spiral.txt') 
                data = spiral(:,1:(end-1));

                true_label = spiral(:,(end-1));

				data = data - repmat(mean(data),size(data,1),1);
				data = data/max(max(abs(data)));	                
                
				halo = true_label;
			    NClusters = max(halo);            
              
            	dim = size(data,2);
				num = size(data,1);
tic;
				
				mdist = [];
				
                for i=1:num  
				  mdist_i = [];
				  for j=i+1:num 
				        mdist_i = [mdist_i;[i,j, sqrt(sum((data(i,:) - data(j,:)) .^ 2)) ]];
                  end
                  mdist = [mdist; mdist_i];
                end
            save fourlinesDPCmdist.dist   mdist -ascii  
					
			load fourlinesDPCmdist.dist;	
            xx = fourlinesDPCmdist;

            ND=max(xx(:,2));
			NL=max(xx(:,1));
			if (NL>ND)
			  ND=NL; 
			end
			 
			N=size(xx,1); 
			 	

			for i=1:ND
			  for j=1:ND
				Dist(i,j)=0;
			  end
            end
	
			for i=1:N
			  ii=xx(i,1);
			  jj=xx(i,2);
			  Dist(ii,jj)=xx(i,3);
			  Dist(jj,ii)=xx(i,3);
            end

			 
			percent=2;
		
			position=round(N*percent/100); 
			[sda,id]=sort(xx(:,3)); 
			dc=sda(position);

     num = size(data,1);
     sig = 3;
     [pd,affinity,distNN,affinityNN,kneigor] = genNNdist(data(:,:),num-1,sig);

     thla = ones(num,1);
     h  =10;
     shortd = rhoshortestdist(distNN,thla,h);
     Dist = shortd;
             k = 10;
             nn = kneigbour(k,Dist);

             kneigh=nn(:,1:round(k));
             rho = sum(kneigh,2)/k;

             rho = rho';
             rho = exp(-(rho).^ 2);
      
			maxd=max(max(Dist));
			 
		
			[rho_sorted,ordrho]=sort(rho,'descend');
            rho_or = rho_sorted;
            ordrho_or = ordrho;
          
			delta(ordrho(1))=-1.;
			nneigh(ordrho(1))=0; 

			for ii=2:ND
			   delta(ordrho(ii))=maxd;
			   for jj=1:ii-1
				 if(Dist(ordrho(ii),ordrho(jj))<delta(ordrho(ii)))
					delta(ordrho(ii))=Dist(ordrho(ii),ordrho(jj));
					nneigh(ordrho(ii))=ordrho(jj);
				 end
			   end
			end
			 
            count= [0 0 0]; 
            choose_num = 0.1*ND;
            dist_ther1_ratio = 0.2;
            punish_ratio = 0.25;
            
            [delta_sorted,orddelta]=sort(delta,'descend');
            
            choose_point = orddelta(1:round(choose_num));
            rho_choose_point = rho(choose_point);
            [~,ordrho_choose]=sort(rho_choose_point,'descend');
            
            for i = 1:size(choose_point,2)
                pair_all(i) = choose_point(ordrho_choose(i));
            end
            
            condition = [];
            
            for i = 2:size(choose_point,2)   
                pair_use = [];
                for j = 1 : i
                    if j == 1
                        pair = [pair_all(i), nneigh(pair_all(i))];
                        pair_use = [pair_use,nneigh(pair_all(i))];
                    else
                        if   ismember(pair_all(j-1),pair_use)
                               continue
                        else
                            pair = [pair_all(i), pair_all(j-1)];
                            pair_use = [pair_use, pair_all(j-1)];
                            
                        end
                    end
                    
                    dist_ther1 = Dist(pair(1),pair(2));
                    dist_ther = dist_ther1 * dist_ther1_ratio;
                    
                    [turn,nei_all,find_time,count,nei_dist] = judge_nei(pair,Dist,count,dc, dist_ther);        
                           
                    if turn == 2
                        
                        punish_time = find_time-5;
                        dist_new = nei_dist  + dist_ther * (1+ punish_time * punish_ratio);
                        
                        Dist(pair(1),pair(2)) = dist_new;
                        Dist(pair(2),pair(1)) = Dist(pair(1),pair(2));
                        if dist_new < delta(pair_all(i))
                            delta(pair_all(i)) = dist_new;
                            nneigh(pair_all(i)) = pair(2);
                        end
                    end

                     if turn == 3 && j == 1
                            max_dist_nei = max(Dist(pair(2),nei_all));
                            Dist(pair(1),pair(2)) =  max_dist_nei * 1.1;
                            Dist(pair(2),pair(1)) = Dist(pair(1),pair(2));
                            delta(pair_all(i)) = Dist(pair(1),pair(2));
                    end                       

                    condition1 = [pair,turn,find_time,nei_dist,dist_ther1,Dist(pair(1),pair(2))];
                    condition = [condition; condition1]; 
                end
                
            end                          

maxd=max(max(Dist));            
delta(ordrho(1))=max(delta(:));  

toc
			scrsz = get(0,'ScreenSize');			 
			 
			fig = figure(2);
			tt=plot(rho(:),delta(:),'o','MarkerFaceColor','b');
			title ('Decision Graph','FontSize',10.0)
			xlabel ('Rho')
			ylabel ('Distance')
			 
			rect = getrect(fig);
			rhomin=rect(1);
			deltamin=rect(2);  
           
        
			NCLUST=0;
            

			for i=1:ND
			  cl(i)=-1;
            end
			 
	
			for i=1:ND
			  if ( (rho(i)>rhomin) && (delta(i)>deltamin))
				 NCLUST=NCLUST+1;
				 cl(i)=NCLUST; 
				 icl(NCLUST)=i;
			  end
            end
					 
					for i=1:ND
					  if (cl(ordrho(i))==-1)
						cl(ordrho(i))=cl(nneigh(ordrho(i)));
					  end
                    end		

					for i=1:ND
					  halo(i)=cl(i);
					end
															
					if (NCLUST>1)
							 
							  for i=1:NCLUST
								bord_rho(i)=0.;
							  end
							 					 
							  
							  for i=1:ND-1
								for j=i+1:ND
								  
								  if ((cl(i)~=cl(j)) && (Dist(i,j)<=dc))
									rho_aver=(rho(i)+rho(j))/2.; 
									
									if (rho_aver>bord_rho(cl(i)))
									  bord_rho(cl(i))=rho_aver;
									end
									
									if (rho_aver>bord_rho(cl(j)))
									  bord_rho(cl(j))=rho_aver;
									end
								  end
								end
                              end
                    end		

			    if (dim==2)	
                      Plot(data,cl);
                      xlabel('(f)');
                      ylabel('');
                      title('DPC-CLD-PRD');
                end

							


















