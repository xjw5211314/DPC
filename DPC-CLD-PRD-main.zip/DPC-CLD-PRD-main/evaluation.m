function evaluation( U,CAT,IDX )
%EVALUATION �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[CA,RI,~]=AccMeasure(CAT,IDX);
NMI=nmi(CAT,IDX);
%figure;
%[S,H]=silhouette(U,IDX);
S=silhouette(U,IDX);
Avg_Silhouette = sum(S) / size(S, 1);

% Dunn's index
dunnIndex=indexDN(U,IDX,'euclidean');
eva=evalclusters(U,'kmeans','DaviesBouldin','klist',[max(IDX)]);
fprintf('Evaluation��CA=%.4f��RI=%.4f��NMI=%.4f\n',CA,RI,NMI)
fprintf('Avg_Silhouette=%.4f, Dunn index=%.4f, DaviesBouldin index=%.4f\n',Avg_Silhouette,dunnIndex,eva.CriterionValues);
end

