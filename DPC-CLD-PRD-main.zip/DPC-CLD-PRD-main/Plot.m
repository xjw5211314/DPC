function  Plot(A,labels)
NC=length(unique(labels));
figure;
% colormap jet
% cmap=colormap;
% cmap=cmap(round(linspace(1,length(cmap),NC+1)),:);
% cmap=cmap(1:end-1,:);
colormap hsv
cmap=colormap;
cmap=cmap(round(linspace(1,length(cmap),NC+1)),:);
cmap=cmap(1:end-1,:)*0.5+0.4;
for i=1:NC
    plot(A(labels == i,1), A(labels == i,2),'o','color',cmap(i,:));
    hold on;
end
xlabel(' ');
ylabel(' ');
end

